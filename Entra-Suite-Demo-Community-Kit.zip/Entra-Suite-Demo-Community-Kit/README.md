# Microsoft Entra Suite — Community Demo Toolkit

> **Community contribution — not official Microsoft documentation.**
> Replace `yourtenant.onmicrosoft.com` and `admin@yourtenant.onmicrosoft.com` with your own demo tenant before running any script.

A complete, end-to-end demo kit for five Microsoft Entra Suite capabilities — each with a step-by-step Technical Runbook and ready-to-run PowerShell automation.

---

## What’s Covered

| # | Demo | Capability | Folder |
|---|------|-----------|--------|
| 0 | Series Overview | All five demos at a glance | `00-Overview/` |
| 1 | Access Reviews | Identity Governance — periodic access review campaigns | `Demo1-AccessReviews/` |
| 2 | Lifecycle Workflows | Automated joiner / leaver identity lifecycle | `Demo2-LifecycleWorkflows/` |
| 3 | Verified ID + Face Check | Passwordless onboarding and visitor-pass issuance | `Demo3-VerifiedID-FaceCheck/` |
| 4 | Internet Access (GSA) | Web content filtering via Global Secure Access | `Demo4-InternetAccess/` |
| 5 | Private Access (GSA) | No-VPN access to internal apps, file shares, and RDP | `Demo5-PrivateAccess/` |

---

## Prerequisites

| Requirement | Notes |
|-------------|-------|
| Microsoft Entra Suite (or equivalent) | Entra ID P2 + Governance + Verified ID + Global Secure Access |
| Global Admin in your demo tenant | All scripts use delegated scopes — no app registration needed |
| PowerShell 5.1 or 7.x | Scripts work on both versions |
| Microsoft.Graph module | Demo 2 includes a one-click installer: `01-Install-GraphModule.ps1` |
| Demo users | Carol Newhire (joiner), Dave Leaver (leaver), Manager Demo — create in your tenant |

---

## Quick Start

### 1 — Read the Series Overview
`00-Overview/Entra-Suite-Demo-Series-Overview.docx` explains the full demo story and how all five demos connect end-to-end.

### 2 — Open the Technical Runbook for the demo you want
Each folder has a `*-Technical-Runbook.docx` with portal step-by-step instructions.

### 3 — Use the scripts for setup and reset
Each `Scripts/` subfolder contains PowerShell automation. Scripts are idempotent — safe to re-run.

---

## Demo-by-Demo Guide

### Demo 1 — Access Reviews
No scripts needed. Follow `Access-Reviews-Technical-Runbook.docx` to configure a recurring access review in Identity Governance.

---

### Demo 2 — Lifecycle Workflows (Joiner / Leaver)

Demo users: **Carol Newhire** (joiner), **Dave Leaver** (leaver), **Manager Demo** (receives notifications).

```powershell
# One-time per machine: install the Graph module
.\01-Install-GraphModule.ps1

# Demo day: just double-click this
RUN-DEMO-PREP.bat
```

The BAT file signs you in, resets Carol & Dave’s attributes, and verifies the environment in one step.

---

### Demo 3 — Verified ID + Face Check

Three scenarios: helpdesk account recovery (stateless), new-hire onboarding (permanent access), contractor visitor pass (expires after 1 day).

```powershell
# First-time: create the demo M365 groups + SharePoint sites
# Edit $AdminUpn near the top of the script first
.\Setup-VerifiedID-Demo-Resources.ps1

# Before every demo run
.\Reset-VerifiedID-GroupMembers.ps1

# Only if a tester already holds an assignment ("you already have access")
.\Reset-VerifiedID-AccessPackageAssignments.ps1
```

> **Note:** `Reset-VerifiedID-AccessPackageAssignments.ps1` and `Remove-VerifiedID-AccessPackages.ps1`
> contain `<YOUR-...-PACKAGE-ID>` placeholders. Replace these with your own access package GUIDs
> (find them in Entra admin center → Identity Governance → Access packages).

---

### Demo 4 — Internet Access (GSA)
No scripts needed. Follow `Demo4-InternetAccess-GSA-Technical-Runbook.docx` to configure a web category filtering policy.

---

### Demo 5 — Private Access (GSA)

Requires two Azure VMs: `gsa-appsrv` (resource server) and `gsa-connector` (Private Network Connector).

```powershell
# On gsa-appsrv: install IIS, SMB share, and enable RDP (once)
Setup-Resources-ONECLICK.bat          # double-click on gsa-appsrv

# On your admin machine: configure GSA segments + user assignment
# Edit $AssignUserUpn near the top of the script first
.\Build-Demo5-Config.ps1

# Soft reset (clears segments + assignment; VMs stay running)
.\Reset-Demo5-Soft.ps1
```

See `Scripts/README-Commands-Reference.md` for diagnostics, connector registration commands, and the critical subnet gotcha.

---

## Customising for Your Tenant

| Placeholder | Replace with |
|-------------|-------------|
| `yourtenant.onmicrosoft.com` | Your demo tenant domain |
| `admin@yourtenant.onmicrosoft.com` | Your Global Admin UPN |
| `[Your Org Name]` | Your org name — used as the Verified ID issuer label in the portal |
| `[Your Organization]` | Your org name — used in sample SharePoint document content |
| `[your admin]` | Your admin username (appears in comments and portal references) |
| `<YOUR-SALES-ONBOARDING-PACKAGE-ID>` | GUID of your “Sales Onboarding” access package |
| `<YOUR-CONTRACTOR-PASS-PACKAGE-ID>` | GUID of your “Contractor Pass” access package |

---

## Folder Structure

```
Entra-Suite-Demo-Community-Kit/
├── README.md
├── 00-Overview/
│   └── Entra-Suite-Demo-Series-Overview.docx
├── Demo1-AccessReviews/
│   └── Access-Reviews-Technical-Runbook.docx
├── Demo2-LifecycleWorkflows/
│   ├── Lifecycle-Workflows-Technical-Runbook.docx
│   └── Scripts/  (01–04 PS1s + BAT launcher + README)
├── Demo3-VerifiedID-FaceCheck/
│   ├── Demo3-VerifiedID-FaceCheck-Technical-Runbook.docx
│   ├── Verified-ID-Technical-Runbook.docx
│   ├── Verified-ID-Setup-Summary.docx
│   └── Scripts/  (setup, reset, rebuild, remove PS1s + BAT launchers + README)
├── Demo4-InternetAccess/
│   └── Demo4-InternetAccess-GSA-Technical-Runbook.docx
└── Demo5-PrivateAccess/
    ├── Demo5-PrivateAccess-Technical-Runbook.docx
    ├── Demo5-PrivateAccess-Build-Sheet.docx
    ├── Demo5-PrivateAccess-Architecture.png
    └── Scripts/  (build, reset, setup PS1s + BAT utilities + README)
```

---

## License

MIT — use freely, adapt for your own demos, share with the community. Attribution appreciated but not required.
